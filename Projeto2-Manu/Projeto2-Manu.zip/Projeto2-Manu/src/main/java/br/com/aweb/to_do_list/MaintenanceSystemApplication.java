package br.com.aweb.to_do_list;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaintenanceSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaintenanceSystemApplication.class, args);
	}

} 	
