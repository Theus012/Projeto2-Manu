package br.com.aweb.to_do_list;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaintenanceSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
